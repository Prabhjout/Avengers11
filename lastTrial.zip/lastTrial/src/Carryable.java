public interface Carryable {
    public String   getContents();
    public String   getDescription();
    public float    getPrice();
}
